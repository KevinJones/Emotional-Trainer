-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 10, 2011 at 07:09 PM
-- Server version: 5.0.77
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cs4911_Team46`
--

-- --------------------------------------------------------

--
-- Table structure for table `ActivityType`
--

CREATE TABLE IF NOT EXISTS `ActivityType` (
  `ActivityID` int(5) NOT NULL auto_increment,
  `ActivityName` varchar(45) NOT NULL,
  PRIMARY KEY  (`ActivityID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `Caregiver`
--

CREATE TABLE IF NOT EXISTS `Caregiver` (
  `CaregiverID` int(11) NOT NULL auto_increment,
  `Name` varchar(45) default NULL,
  `DOB` date default NULL,
  `Picture` mediumblob,
  `Email` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `TermsConsent` varchar(10) NOT NULL,
  `EmailConsent` varchar(10) NOT NULL,
  PRIMARY KEY  (`CaregiverID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=145 ;

-- --------------------------------------------------------

--
-- Table structure for table `Child`
--

CREATE TABLE IF NOT EXISTS `Child` (
  `ChildID` int(11) NOT NULL auto_increment,
  `CaregiverID` int(11) NOT NULL,
  `Name` varchar(45) default NULL,
  `DOB` date default NULL,
  `Picture` mediumblob,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `AutisticSpec` varchar(45) default NULL,
  `Score` int(11) default NULL,
  `imgType` varchar(255) NOT NULL,
  PRIMARY KEY  (`ChildID`),
  KEY `CaregiverID` (`CaregiverID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=223 ;

-- --------------------------------------------------------

--
-- Table structure for table `ChildHasMedia`
--

CREATE TABLE IF NOT EXISTS `ChildHasMedia` (
  `ChildID` int(5) NOT NULL,
  `MediaID` int(5) NOT NULL,
  PRIMARY KEY  (`ChildID`,`MediaID`),
  KEY `ChildID` (`ChildID`),
  KEY `MediaID` (`MediaID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Emotion`
--

CREATE TABLE IF NOT EXISTS `Emotion` (
  `EmotionID` int(5) NOT NULL auto_increment,
  `EmotionName` varchar(50) NOT NULL,
  PRIMARY KEY  (`EmotionID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `Media`
--

CREATE TABLE IF NOT EXISTS `Media` (
  `MediaID` int(5) NOT NULL auto_increment,
  `Media` mediumblob NOT NULL,
  `EmotionID` int(11) default NULL,
  `TypeID` int(5) NOT NULL,
  `FileType` varchar(255) default NULL,
  PRIMARY KEY  (`MediaID`),
  KEY `TypeID` (`TypeID`),
  KEY `EmotionID` (`EmotionID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

-- --------------------------------------------------------

--
-- Table structure for table `RecentActivity`
--

CREATE TABLE IF NOT EXISTS `RecentActivity` (
  `RecentActivityID` int(5) NOT NULL auto_increment,
  `ChildID` int(5) NOT NULL,
  `Date` date NOT NULL,
  `ActivityID` int(5) NOT NULL,
  `EmotionID` int(5) default NULL,
  `Score` int(5) default NULL,
  PRIMARY KEY  (`RecentActivityID`),
  KEY `ChildID` (`ChildID`),
  KEY `EmotionID` (`EmotionID`),
  KEY `ActivityID` (`ActivityID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Type`
--

CREATE TABLE IF NOT EXISTS `Type` (
  `TypeID` int(5) NOT NULL auto_increment,
  `TypeName` varchar(15) NOT NULL,
  PRIMARY KEY  (`TypeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Child`
--
ALTER TABLE `Child`
  ADD CONSTRAINT `Child_ibfk_1` FOREIGN KEY (`CaregiverID`) REFERENCES `Caregiver` (`CaregiverID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ChildHasMedia`
--
ALTER TABLE `ChildHasMedia`
  ADD CONSTRAINT `ChildHasMedia_ibfk_2` FOREIGN KEY (`MediaID`) REFERENCES `Media` (`MediaID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ChildHasMedia_ibfk_1` FOREIGN KEY (`ChildID`) REFERENCES `Child` (`ChildID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Media`
--
ALTER TABLE `Media`
  ADD CONSTRAINT `Media_ibfk_2` FOREIGN KEY (`TypeID`) REFERENCES `Type` (`TypeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Media_ibfk_1` FOREIGN KEY (`EmotionID`) REFERENCES `Emotion` (`EmotionID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `RecentActivity`
--
ALTER TABLE `RecentActivity`
  ADD CONSTRAINT `RecentActivity_ibfk_1` FOREIGN KEY (`ChildID`) REFERENCES `Child` (`ChildID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RecentActivity_ibfk_2` FOREIGN KEY (`ActivityID`) REFERENCES `ActivityType` (`ActivityID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RecentActivity_ibfk_3` FOREIGN KEY (`EmotionID`) REFERENCES `Emotion` (`EmotionID`) ON DELETE CASCADE ON UPDATE CASCADE;
